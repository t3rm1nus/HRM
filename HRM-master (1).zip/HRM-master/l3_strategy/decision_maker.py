"""
Decision Maker - L3
Toma los outputs de todos los módulos de L3 (regime, sentiment, portfolio, risk, macro)
y genera las directrices estratégicas unificadas para L2.
ENHANCED: Now handles oversold/overbought setups within range regimes.
"""

import os
import json
from datetime import datetime
from .regime_classifier import clasificar_regimen_mejorado as clasificar_regimen
from .exposure_manager import gestionar_exposicion
from core.logging import logger
from typing import Dict, Optional, List, Any

import numpy as np  # Needed for generate_strategic_signal

# Directorio de inferencias
INFER_DIR = "data/datos_inferencia"
OUTPUT_FILE = os.path.join(INFER_DIR, "strategic_decision.json")

# WEAK SIGNALS BLOCKED - Aggressive mode enabled (lowered from 0.55 to 0.45)
WEAK_THRESHOLD = 0.45

# MINIMUM CONFIDENCE THRESHOLD - Below this, L2 signals are blocked
MIN_CONFIDENCE_THRESHOLD = 0.35


def ensure_dir(directory: str):
    """Crea el directorio si no existe"""
    if not os.path.exists(directory):
        os.makedirs(directory)


def load_inputs():
    """Carga todos los JSON disponibles en data/datos_inferencia"""
    results = {}
    for file in os.listdir(INFER_DIR):
        if file.endswith(".json") and file not in ["l3_output.json", "strategic_decision.json"]:
            path = os.path.join(INFER_DIR, file)
            try:
                with open(path, "r") as f:
                    data = json.load(f)
                    results[file.replace(".json", "")] = data
            except Exception as e:
                print(f"⚠️ Error cargando {file}: {e}")
    return results


def _check_real_balances(state: Dict) -> bool:
    """
    Check if real balances are available in the portfolio.
    FIX: Check both legacy fields and portfolio structure.
    CRITICAL: This must check the SAME state that was updated by sync_balances.
    """
    portfolio = state.get('portfolio', {})
    
    # CRITICAL FIX: Also check direct state keys as backup
    btc_balance = portfolio.get('btc_balance', 0)
    eth_balance = portfolio.get('eth_balance', 0)
    usdt_balance = portfolio.get('usdt_balance', 0)
    
    if btc_balance == 0 and eth_balance == 0:
        btc_balance = state.get('btc_balance', 0)
        eth_balance = state.get('eth_balance', 0)
        usdt_balance = state.get('usdt_balance', 0)
        
        if btc_balance > 0 or eth_balance > 0:
            portfolio = {
                'btc_balance': btc_balance,
                'eth_balance': eth_balance,
                'usdt_balance': usdt_balance
            }
            state['portfolio'] = portfolio
    btc = portfolio.get('btc_balance', state.get('btc_balance', 0))
    eth = portfolio.get('eth_balance', state.get('eth_balance', 0))
    usdt = portfolio.get('usdt_balance', state.get('usdt_balance', 0))
    
    has_crypto = btc > 0 or eth > 0
    has_traded = usdt < 3000.0
    has_valid_portfolio = has_crypto or has_traded
    
    # DEBUG: Log what we're checking
    logger.debug(f"🔍 _check_real_balances - portfolio: {portfolio}")
    logger.debug(f"🔍 _check_real_balances - legacy fields: btc={state.get('btc_balance', 0)}, eth={state.get('eth_balance', 0)}, usdt={state.get('usdt_balance', 0)}")
    logger.debug(f"🔍 _check_real_balances - has_crypto: {has_crypto}, has_traded: {has_traded}, result: {has_valid_portfolio}")
    
    return has_valid_portfolio


def generate_strategic_decision(regime_data):
    """Generate strategic decision based on regime and indicators"""
    
    regime = regime_data.get('regime', 'NEUTRAL')
    confidence = regime_data.get('confidence', 0.5)
    rsi = regime_data.get('rsi', 50.0)
    adx = regime_data.get('adx', 20.0)
    
    # ✅ FIX 1: TRENDING con RSI > 70 → SELL
    if regime == "TRENDING":
        if rsi > 80:
            return {
                'signal': 'sell',
                'confidence': confidence,
                'allow_l2_signals': True,
                'reason': f'TRENDING + EXTREME_OVERBOUGHT (RSI={rsi:.1f})',
                'allocation': {'BTC': 0.0, 'ETH': 0.0, 'USDT': 1.0}
            }
        elif rsi > 70:
            return {
                'signal': 'sell',
                'confidence': confidence * 0.8,
                'allow_l2_signals': True,
                'reason': f'TRENDING + OVERBOUGHT (RSI={rsi:.1f})',
                'allocation': {'BTC': 0.2, 'ETH': 0.1, 'USDT': 0.7}
            }
        elif rsi < 30:
            return {
                'signal': 'buy',
                'confidence': confidence,
                'allow_l2_signals': True,
                'reason': f'TRENDING + OVERSOLD (RSI={rsi:.1f})',
                'allocation': {'BTC': 0.5, 'ETH': 0.3, 'USDT': 0.2}
            }
        else:
            # Neutral trending - let L2 decide
            return {
                'signal': 'hold',
                'confidence': confidence,
                'allow_l2_signals': True,  # ✅ PERMITIR L2
                'reason': 'TRENDING - L2 can act',
                'allocation': None  # L2 decides
            }
    
    # ✅ FIX 2: RANGE regime
    elif regime == "RANGE":
        return {
            'signal': 'hold',
            'confidence': confidence,
            'allow_l2_signals': True,  # ✅ PERMITIR L2 mean-reversion
            'reason': 'RANGE - L2 handles oscillations',
            'allocation': None
        }
    
    # Default fallback
    return {
        'signal': 'hold',
        'confidence': 0.5,
        'allow_l2_signals': True,
        'reason': 'NEUTRAL - L2 can act',
        'allocation': None
    }

def make_decision(inputs: dict, portfolio_state: dict = None, market_data: dict = None, regime_decision: dict = None, state: dict = None):
    """
    Combina todos los outputs de L3 en una decisión estratégica.
    SOLUCIÓN CRÍTICA: SAFE FALLBACK ≠ REBALANCE

    PRIORITY HIERARCHY:
    1. BALANCES SYNC CHECK - Skip L3 if no real balances available
    2. Regime-specific decisions with STRATEGIC CAPITAL PRESERVATION
    3. Confidence-based HOLD overrides (< 0.7 forces HOLD)
    4. Setup detection for controlled L2 signals
    5. Sentiment adjustments
    6. Risk management overlays

    SEPARACIÓN CRÍTICA: OPINIÓN vs ORDEN
    - opinion: Lo que L3 "piensa" del mercado
    - order: Lo que L3 ORDENA hacer (solo cuando puede ver balances)
    """

    # ========================================================================================
    # OBTENER RSI DEL MERCADO PARA INCLUIRLO EN EL CONTEXTO L3
    # ========================================================================================
    rsi = 50.0  # Valor predeterminado neutral
    if market_data:
        # Calcular RSI promedio de BTC y ETH (símbolos principales)
        rsi_values = []
        for symbol in ["BTCUSDT", "ETHUSDT"]:
            if symbol in market_data:
                symbol_data = market_data[symbol]
                if isinstance(symbol_data, dict) and 'historical_data' in symbol_data:
                    df = symbol_data['historical_data']
                    if isinstance(df, pd.DataFrame) and len(df) > 14:
                        try:
                            # Calcular RSI (14 periodos)
                            delta = df['close'].diff()
                            gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
                            loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
                            rs = gain / loss
                            symbol_rsi = 100 - (100 / (1 + rs))
                            rsi_values.append(symbol_rsi.iloc[-1])
                        except Exception as e:
                            logger.debug(f"Error calculating RSI for {symbol}: {e}")
                            continue
        if rsi_values:
            rsi = sum(rsi_values) / len(rsi_values)
            logger.debug(f"Calculated average RSI: {rsi:.1f}")

    # ========================================================================================
    # CRÍTICO: SYSTEM STATE CHECK - PRIORITY 1 - USE STATE COORDINATOR SOURCE OF TRUTH
    # ========================================================================================
    # FIX: Use SystemState from StateCoordinator as the ONLY source of truth
    if state and state.get('system_state_type') != 'NORMAL':
        logger.warning(f"🚨 SYSTEM STATE {state.get('system_state_type')}: L3 decisions blocked - not in NORMAL state")
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "market_regime": "unknown_no_sync",
            "regime_subtype": None,
            "setup_detected": False,
            "setup_type": None,
            "setup_active": False,
            "market_opinion": "hold",
            "opinion_confidence": 0.0,
            "market_bias": "neutral",
            "bias": "hold",
            "allow_l2_signals": False,
            "strategic_hold_active": True,
            "strategic_hold_reason": "SYSTEM_BLIND - L3 cannot issue orders without balance visibility",
            "sentiment_score": 0.0,
            "asset_allocation": None,
            "risk_appetite": "low",
            "macro_context": {},
            "exposure_decisions": {},
            "loss_prevention_filters": {
                "max_loss_per_trade_pct": 0.01,
                "require_strong_signal": True,
                "avoid_weak_sentiment": True,
                "bear_market_restriction": True,
                "high_volatility_block": True,
                "preserve_high_conf_l2": False,
                "allow_setup_trades": False,
                "setup_type": None
            },
            "winning_trade_rules": {
                "allow_profit_running": False,
                "trailing_stop_activation": 0.005,
                "take_profit_levels": [0.01],
                "scale_out_profits": False,
                "hold_winners_longer": False,
                "momentum_boost": False,
                "early_exit_weak_signals": True,
                "profit_lock_in": 0.005,
            },
            "strategic_control": {
                'allow_l2_signals': False,
                'strategic_hold_active': True,
                'strategic_hold_type': 'SYSTEM_BLIND',
                'strategic_hold_reason': 'L3 cannot issue orders without balance visibility',
                'capital_preservation_mode': True,
                'l2_signals_blocked': True,
                'block_autorebalancer': True,
                'freeze_positions': True,
                'allow_only_stop_loss': True,
                'blind_mode_active': True,
                'force_hold_signals': True
            },
            "strategic_guidelines": {
                "rebalance_frequency": "never",
                "max_single_asset_exposure": 0.0,
                "volatility_target": 0.05,
                "liquidity_requirement": "maximum",
                "btc_max_exposure": 0.0,
                "usdt_min_liquidity": 1.0,
                "max_loss_per_trade_pct": 0.01,
                "require_stop_loss": True,
                "profit_taking_strategy": "immediate",
                "setup_trading_enabled": False
            },
            "blind_mode": True,
            "rsi": rsi  # Incluir RSI en el contexto
        }
    
    # If state is NORMAL or not provided, proceed with normal L3 logic
    balances_synced = True

    if not balances_synced:
        logger.warning("🚨 L3 DECISION SKIPPED: System state not NORMAL - cannot make strategic decisions")
        logger.warning("📊 L3 will return BLIND MODE - opinion only, no orders")

        # Return BLIND MODE decision - OPINIÓN PERO NO ÓRDENES
        blind_decision = {
            "timestamp": datetime.utcnow().isoformat(),
            "market_regime": "unknown_no_sync",
            "regime_subtype": None,
            "setup_detected": False,
            "setup_type": None,
            "setup_active": False,
            # OPINIÓN: L3 puede tener opinión del mercado PERO EN BLIND MODE = NEUTRAL/HOLD
            "market_opinion": "hold",  # CRÍTICO: En BLIND MODE opinión = HOLD
            "opinion_confidence": 0.0,  # Sin confianza en BLIND MODE
            "market_bias": "neutral",  # Neutral en BLIND MODE
            # ÓRDENES: Pero NO ORDENA NADA (blind mode)
            "bias": "hold",  # SAFE FALLBACK = HOLD ABSOLUTO
            "allow_l2_signals": False,  # CRITICAL: Block all L2 signals when blind
            "strategic_hold_active": True,
            "strategic_hold_reason": "SYSTEM_BLIND - L3 cannot issue orders without balance visibility",
            "sentiment_score": 0.0,
            "asset_allocation": None,  # CRITICAL FIX: No allocation when blind
            "risk_appetite": "low",
            "macro_context": {},
            "exposure_decisions": {},
            "loss_prevention_filters": {
                "max_loss_per_trade_pct": 0.01,
                "require_strong_signal": True,
                "avoid_weak_sentiment": True,
                "bear_market_restriction": True,
                "high_volatility_block": True,
                "preserve_high_conf_l2": False,
                "allow_setup_trades": False,
                "setup_type": None
            },
            "winning_trade_rules": {
                "allow_profit_running": False,
                "trailing_stop_activation": 0.005,
                "take_profit_levels": [0.01],
                "scale_out_profits": False,
                "hold_winners_longer": False,
                "momentum_boost": False,
                "early_exit_weak_signals": True,
                "profit_lock_in": 0.005,
            },
            "strategic_control": {
                'allow_l2_signals': False,
                'strategic_hold_active': True,
                'strategic_hold_type': 'SYSTEM_BLIND',
                'strategic_hold_reason': 'L3 cannot issue orders without balance visibility',
                'capital_preservation_mode': True,
                'l2_signals_blocked': True,  # CRÍTICO: Bloquear AutoRebalancer
                'block_autorebalancer': True,  # CRÍTICO: Bloquear AutoRebalancer
                'freeze_positions': True,  # CRÍTICO: Congelar posiciones
                'allow_only_stop_loss': True,  # Solo stop losses permitidos
                'blind_mode_active': True,  # FLAG EXPLÍCITO PARA BLIND MODE
                'force_hold_signals': True  # FORZAR HOLD EN TODOS LOS NIVELES
            },
            "strategic_guidelines": {
                "rebalance_frequency": "never",
                "max_single_asset_exposure": 0.0,
                "volatility_target": 0.05,
                "liquidity_requirement": "maximum",
                "btc_max_exposure": 0.0,
                "usdt_min_liquidity": 1.0,
                "max_loss_per_trade_pct": 0.01,
                "require_stop_loss": True,
                "profit_taking_strategy": "immediate",
                "setup_trading_enabled": False
            }
        }
        
        # FIX EXTRA - BLIND MODE HANDLING
        # Asegurar que blind_mode esté presente en la decisión
        blind_decision['blind_mode'] = True

        logger.info("🛡️ SYSTEM_BLIND MODE: L3 can have market opinion but issues no orders")
        logger.info("BLIND MODE: keeping current portfolio allocation unchanged")
        return blind_decision

    # Initialize variables that may be used outside the regime_decision block
    setup_active = False
    regime = 'neutral'
    subtype = None
    regime_signal = 'hold'
    regime_confidence = 0.5
    setup_type = None
    allow_l2_signal = True  # ✅ DEFAULT: L2 siempre activo
    risk_appetite = 'moderate'
    portfolio = {'BTC': 0.40, 'ETH': 0.30, 'USDT': 0.30}  # Default portfolio
    strategic_hold_reason = None
    strategic_hold_type = None
    l3_dominance_state = {
        'allow_l2_signals': True,  # ✅ DEFAULT: L2 siempre activo
        'strategic_hold_active': False,  # Default: no bloqueo estratégico
        'strategic_hold_type': None,
        'strategic_hold_reason': None,
        'capital_preservation_mode': False,
        'l2_signals_blocked': False  # ✅ DEFAULT: L2 siempre activo
    }

    # ========================================================================================
    # PRIORITY 1: REGIME-SPECIFIC STRATEGIC DECISIONS WITH CAPITAL PRESERVATION
    # ========================================================================================
    if regime_decision and isinstance(regime_decision, dict):
        regime = regime_decision.get('regime', 'neutral')
        subtype = regime_decision.get('subtype', None)
        regime_signal = regime_decision.get('signal', 'hold')
        regime_confidence = float(np.clip(regime_decision.get('confidence', 0.5), 0.0, 1.0))
        setup_type = regime_decision.get('setup_type', None)
        setup_active = setup_type is not None  # True when setup is detected
        allow_l2_signal = True  # ✅ DEFAULT: L2 siempre activo

        # ========================================================================================
        # PRELIMINARY LOSS PREVENTION FILTERS FOR STRATEGIC HOLD LOGIC
        # ========================================================================================
        # Initialize basic loss_prevention_filters for strategic hold decision
        preliminary_loss_filters = {
            "allow_setup_trades": setup_type is not None,
            "setup_type": setup_type
        }

        # EXPLICIT TIGHT_RANGE DETECTION: Set loss_prevention_filters dynamically by regime
        if regime == "RANGE" and subtype == "TIGHT_RANGE":
            preliminary_loss_filters["allow_setup_trades"] = True
            preliminary_loss_filters["setup_type"] = "mean_reversion"

        # ========================================================================================
        # ÚNICA FUENTE DE VERDAD PARA L3 DOMINANCE STATE
        # ========================================================================================
        # Estado persistente del ciclo - se evalúa UNA sola vez
        l3_dominance_state = {
            'allow_l2_signals': True,  # ✅ DEFAULT: L2 siempre activo
            'strategic_hold_active': False,  # Default: no bloqueo estratégico
            'strategic_hold_type': None,
            'strategic_hold_reason': None,
            'capital_preservation_mode': False,
            'l2_signals_blocked': False  # ✅ DEFAULT: L2 siempre activo
        }

        # ========================================================================================
        # EVALUACIÓN DE DOMINANCIA L3 - UNA SOLA VEZ POR CICLO
        # ========================================================================================
        
        # CRITICAL RULE 0: LOW CONFIDENCE BLOCK - When confidence < MIN_CONFIDENCE_THRESHOLD (0.35)
        # This is the highest priority rule - it blocks all L2 signals when confidence is too low
        if regime_confidence < MIN_CONFIDENCE_THRESHOLD:
            l3_dominance_state.update({
                'allow_l2_signals': False,  # 🛡️ BLOCK L2 signals
                'strategic_hold_active': True,
                'strategic_hold_reason': f"LOW CONFIDENCE HOLD: confidence {regime_confidence:.2f} < {MIN_CONFIDENCE_THRESHOLD} - blocking active signals",
                'strategic_hold_type': "HOLD_L3_LOW_CONFIDENCE",
                'capital_preservation_mode': True,
                'l2_signals_blocked': True,
                'block_autorebalancer': False,  # Rebalancer has its own grace period control
                'freeze_positions': True
            })
            regime_signal = 'hold'
            # SINGLE CLEAR LOG MESSAGE - No other logs for this condition
            logger.warning(f"🛡️ LOW CONFIDENCE HOLD: confidence={regime_confidence:.2f} < {MIN_CONFIDENCE_THRESHOLD} - blocking active signals")

        # RULE GOLD: TRENDING regime with confidence < 0.5 should NEVER block setups
        elif regime == "TRENDING" and regime_confidence < 0.5:
            logger.info(f"🎯 TRENDING LOW CONFIDENCE RULE: confidence {regime_confidence:.2f} < 0.5 - treating as UNCERTAIN, allowing setup trades")
            l3_dominance_state.update({
                'allow_l2_signals': True,
                'strategic_hold_active': False,
                'strategic_hold_reason': f"TRENDING regime confidence {regime_confidence:.2f} < 0.5 threshold - allowing setups",
                'strategic_hold_type': None,
                'l2_signals_blocked': False,
                'allow_setup_trades': True,
                'low_confidence_trending': True
            })

        # TIGHT_RANGE = MEAN REVERSION OPPORTUNITY (no bloqueo)
        elif regime == 'RANGE' and subtype == 'TIGHT_RANGE':
            logger.info(f"🎯 TIGHT RANGE MEAN REVERSION: Enabling L2 signals for mean reversion in tight range")
            # Configurar para permitir mean reversion
            setup_type = 'mean_reversion'  # Update global setup_type
            l3_dominance_state.update({
                'allow_l2_signals': True,
                'strategic_hold_active': False,
                'l2_signals_blocked': False,
                'mean_reversion_mode': True,
                'allow_setup_trades': True,
                'setup_type': 'mean_reversion'
            })
        else:
            # RULE 1: HOLD strategic con asset allocation = permitir rebalance pero bloquear señales L2
            if regime_signal == 'hold':
                # Si hay asset allocation, permitir rebalance pero bloquear señales L2
                if portfolio and sum(portfolio.values()) > 0:
                    l3_dominance_state.update({
                        'allow_l2_signals': True,  # ✅ PERMITIR L2
                        'strategic_hold_active': True,
                        'strategic_hold_reason': f"Strategic HOLD active but asset allocation present - allowing rebalance",
                        'strategic_hold_type': "HOLD_L3_STRATEGIC_ALLOCATION",
                        'l2_signals_blocked': False,  # Permitir rebalance
                        'block_autorebalancer': False,  # Permitir AutoRebalancer
                        'freeze_positions': False  # No congelar posiciones
                    })
                    logger.info(f"🎯 STRATEGIC HOLD CON ALLOCATION: Permitiendo rebalance y señales L2")
                else:
                    l3_dominance_state.update({
                        'allow_l2_signals': True,  # ✅ PERMITIR L2
                        'strategic_hold_active': True,
                        'strategic_hold_reason': f"Strategic HOLD active - L2 signals allowed",
                        'strategic_hold_type': "HOLD_L3_STRATEGIC",
                        'l2_signals_blocked': False,
                        'block_autorebalancer': False,
                        'freeze_positions': False
                    })
                    logger.info(f"🛡️ STRATEGIC HOLD: L3 emitting HOLD - allowing L2 signals and rebalance")

            # RULE 2: WEAK SIGNALS BLOCKED - Apply WEAK_THRESHOLD logic (only when confidence >= MIN_CONFIDENCE_THRESHOLD)
            elif regime_confidence < WEAK_THRESHOLD:
                # WEAK_THRESHOLD: Block signals when confidence < 0.45 (but >= 0.35)
                l3_dominance_state.update({
                    'allow_l2_signals': True,  # ✅ PERMITIR L2 (but with caution)
                    'strategic_hold_active': True,
                    'strategic_hold_reason': f"WEAK SIGNALS BLOCKED: confidence {regime_confidence:.2f} < {WEAK_THRESHOLD} threshold",
                    'strategic_hold_type': "HOLD_L3_WEAK_SIGNALS_BLOCKED",
                    'capital_preservation_mode': True,
                    'l2_signals_blocked': False,
                    'block_autorebalancer': False,
                    'freeze_positions': False
                })
                regime_signal = 'hold'
                logger.warning(f"🚨 WEAK SIGNALS BLOCKED: confidence {regime_confidence:.2f} < {WEAK_THRESHOLD} - FORCING HOLD")

            # RULE 2B: RANGE regime capital preservation (only when confidence >= WEAK_THRESHOLD)
            elif regime == 'RANGE':
                if regime_confidence < 0.7:
                    # CONFIDENCE OVERRIDE: Force HOLD when confidence < 0.7 in RANGE (but >= WEAK_THRESHOLD)
                    l3_dominance_state.update({
                        'allow_l2_signals': True,  # ✅ PERMITIR L2
                        'strategic_hold_active': True,
                        'strategic_hold_reason': f"RANGE regime confidence {regime_confidence:.2f} < 0.7 threshold (but >= {WEAK_THRESHOLD})",
                        'strategic_hold_type': "HOLD_L3_CONFIDENCE_OVERRIDE",
                        'capital_preservation_mode': True,
                        'l2_signals_blocked': False
                    })
                    regime_signal = 'hold'
                    logger.warning(f"🚨 STRATEGIC HOLD: RANGE regime confidence {regime_confidence:.2f} < 0.7 - FORCING HOLD (L3 dominance)")

            # RULE 3: RANGE regime strategic hold logic - follows user's exact requirement
                else:
                    # Apply user's strategic hold logic: if RANGE and not allow_setup_trades, then strategic_hold = True
                    if regime == "RANGE" and not preliminary_loss_filters["allow_setup_trades"]:
                        strategic_hold = True
                        l3_dominance_state.update({
                            'allow_l2_signals': True,  # ✅ PERMITIR L2
                            'strategic_hold_active': True,
                            'strategic_hold_reason': "RANGE regime default - allowing L2 signals",
                            'strategic_hold_type': "HOLD_L3_RANGE_DEFAULT",
                            'l2_signals_blocked': False
                        })
                        logger.info(f"🔒 STRATEGIC CONTROL: RANGE regime detected - allow_l2_signals = True")
                    else:
                        strategic_hold = False
                        logger.info(f"🔓 RANGE SETUP ALLOWED: allow_setup_trades={preliminary_loss_filters['allow_setup_trades']} - skipping strategic hold")

            # RULE 4: Allow signals in clear directional regimes with high confidence
            elif regime in ['BULL', 'BEAR'] and regime_confidence >= 0.8:
                l3_dominance_state.update({
                    'allow_l2_signals': True,
                    'strategic_hold_active': False,
                    'l2_signals_blocked': False
                })
                logger.info(f"✅ L3 ALLOWANCE: {regime} regime with high confidence ({regime_confidence:.2f}) - L2 signals allowed")

            # RULE 5: Default - allow L2 signals
            else:
                l3_dominance_state.update({
                    'allow_l2_signals': True,
                    'strategic_hold_active': False,
                    'strategic_hold_reason': f"Allowing L2 signals in {regime} regime",
                    'l2_signals_blocked': False
                })
                logger.info(f"✅ L2 SIGNALS ALLOWED: L3 allowing L2 signals in {regime} regime")

        # ========================================================================================
        # SETUP OVERRIDE: Allow controlled L2 signals for documented setups
        # ========================================================================================
        if setup_type in ['oversold', 'overbought']:
            l3_dominance_state.update({
                'allow_l2_signals': True,
                'strategic_hold_active': False,
                'strategic_hold_reason': None,
                'strategic_hold_type': None,
                'l2_signals_blocked': False,
                'allow_setup_trades': True,
                'setup_type': setup_type
            })
            logger.info(f"🎯 SETUP EXCEPTION: Allowing L2 signals for {setup_type} setup despite {regime} regime")
            if l3_dominance_state.get('strategic_hold_type'):
                logger.warning(f"⚠️ SETUP OVERRIDE: {setup_type} setup overrides strategic HOLD ({l3_dominance_state['strategic_hold_type']})")

        # ========================================================================================
        # ACTUALIZAR VARIABLES GLOBALES CON FUENTE ÚNICA DE VERDAD
        # ========================================================================================
        allow_l2_signal = l3_dominance_state['allow_l2_signals']
        strategic_hold_reason = l3_dominance_state.get('strategic_hold_reason')
        strategic_hold_type = l3_dominance_state.get('strategic_hold_type')

        # Get current prices for allocation calculations
        current_btc_price = None
        current_eth_price = None

        if market_data:
            if "BTCUSDT" in market_data:
                btc_data = market_data["BTCUSDT"]
                if isinstance(btc_data, dict) and 'close' in btc_data:
                    current_btc_price = float(btc_data['close'])
                elif hasattr(btc_data, 'iloc') and len(btc_data) > 0:
                    try:
                        current_btc_price = float(btc_data['close'].iloc[-1])
                    except:
                        pass

            if "ETHUSDT" in market_data:
                eth_data = market_data["ETHUSDT"]
                if isinstance(eth_data, dict) and 'close' in eth_data:
                    current_eth_price = float(eth_data['close'])
                elif hasattr(eth_data, 'iloc') and len(eth_data) > 0:
                    try:
                        current_eth_price = float(eth_data['close'].iloc[-1])
                    except:
                        pass

        # ========================================================================================
        # NEW: SETUP-BASED ALLOCATIONS (Override standard regime logic)
        # ========================================================================================
        if setup_type == 'oversold':
            # OVERSOLD SETUP: Small buy allocation for mean reversion
            portfolio = {
                'BTC': 0.15,  # 15% allocation
                'ETH': 0.10,  # 10% allocation
                'USDT': 0.75      # Keep 75% liquid
            }
            risk_appetite = 'moderate'
            logger.info(f"🎯 OVERSOLD SETUP: Allowing limited L2 BUY signals with {regime_confidence:.2f} confidence")
            logger.info(f"📊 Target allocation: BTC 15%, ETH 10%, USDT 75%")
            
        elif setup_type == 'overbought':
            # OVERBOUGHT SETUP: Small short allocation or exit longs
            portfolio = {
                'BTC': 0.05,  # Reduce to 5%
                'ETH': 0.05,  # Reduce to 5%
                'USDT': 0.90      # Move to 90% cash
            }
            risk_appetite = 'low'
            logger.info(f"🎯 OVERBOUGHT SETUP: Allowing limited L2 SELL signals with {regime_confidence:.2f} confidence")
            logger.info(f"📊 Target allocation: BTC 5%, ETH 5%, USDT 90%")
            
        # ========================================================================================
        # STANDARD REGIME ALLOCATIONS (when no setup detected)
        # ========================================================================================
        elif regime_signal == 'buy':
            if regime == 'bull':
                # Aggressive allocations in bull markets
                portfolio = {
                    'BTC': 0.60,
                    'ETH': 0.30,
                    'USDT': 0.10
                }
            elif regime == 'bear':
                # Conservative allocations in bear markets
                portfolio = {
                    'BTC': 0.00,
                    'ETH': 0.00,
                    'USDT': 1.00
                }
            else:  # range, neutral
                # Balanced allocations
                portfolio = {
                    'BTC': 0.40,
                    'ETH': 0.30,
                    'USDT': 0.30
                }
        else:
            # Default HOLD allocations
            portfolio = {
                'BTC': 0.40,
                'ETH': 0.30,
                'USDT': 0.30
            }

        logger.info(f"🎯 REGIME PRIORITY: {regime.upper()} regime (subtype: {subtype}) with {regime_confidence:.2f} confidence")
        if setup_type:
            logger.info(f"🎯 SETUP DETECTED: {setup_type} - Mean reversion strategy active")

        # Override risk appetite based on regime and setup
        if setup_type:
            risk_appetite = 'moderate'  # Always moderate for setups
        elif regime == 'bull':
            risk_appetite = 'high'
        elif regime == 'bear':
            risk_appetite = 'low'
        else:
            risk_appetite = 'moderate'

    else:
        # Fallback when no regime decision provided
        regime = clasificar_regimen(market_data) if market_data else inputs.get("regime_detection", {}).get("predicted_regime", "neutral")
        portfolio = inputs.get("portfolio", {}).get("weights", {})
        subtype = None
        setup_type = None
        allow_l2_signal = False

    # Get remaining inputs
    sentiment = inputs.get("sentiment", {}).get("sentiment_score", 0.0)
    if 'risk_appetite' not in locals():
        risk_appetite = inputs.get("risk", {}).get("risk_appetite", "moderate")
    macro = inputs.get("macro", {})

    # ========================================================================================
    # EXPOSURE MANAGEMENT - FIX: Provide default exposure decisions when data is insufficient
    # ========================================================================================
    exposure_decisions = {}
    
    # Get data completeness from regime_decision if available
    regime_data_completeness = regime_decision.get('data_completeness', 1.0) if regime_decision else 1.0
    regime_available_candles = regime_decision.get('available_candles', 0) if regime_decision else 0
    regime_required_candles = regime_decision.get('required_candles', 360) if regime_decision else 360
    
    if portfolio_state and market_data:
        universo = ["BTCUSDT", "ETHUSDT"]
        exposure_decisions = gestionar_exposicion(universo, portfolio_state, market_data, regime)
        logger.info("📊 Decisiones de exposición calculadas exitosamente")
    else:
        # Log warning with data completeness context
        if regime_data_completeness < 0.5:
            logger.warning(f"⚠️ Datos insuficientes para gestión de exposición - Régimen clasificado con {regime_available_candles}/{regime_required_candles} velas ({regime_data_completeness:.1%})")
        else:
            logger.warning("⚠️ Datos insuficientes para gestión de exposición - portfolio_state o market_data no disponibles")
        
        # FIX: Provide default exposure decisions instead of empty dict
        # Default allocations based on regime and data completeness
        if regime_data_completeness < 0.5:
            # When data is insufficient, be more conservative
            target_allocations = {'BTC': 0.30, 'ETH': 0.20, 'USDT': 0.50}
            exposure_reason = f'Conservative allocation - insufficient regime data ({regime_data_completeness:.1%})'
        elif regime.lower() == "bear":
            target_allocations = {'BTC': 0.00, 'ETH': 0.00, 'USDT': 1.00}
            exposure_reason = 'Default allocation - bear regime'
        elif regime.lower() == "bull":
            target_allocations = {'BTC': 0.60, 'ETH': 0.30, 'USDT': 0.10}
            exposure_reason = 'Default allocation - bull regime'
        else:
            target_allocations = {'BTC': 0.40, 'ETH': 0.30, 'USDT': 0.30}
            exposure_reason = 'Default allocation - neutral regime'
        
        # Create default exposure decisions
        exposure_decisions = {
            'BTC': {
                'action': 'hold',
                'target_allocation': target_allocations['BTC'],
                'reason': exposure_reason,
                'data_completeness': regime_data_completeness
            },
            'ETH': {
                'action': 'hold',
                'target_allocation': target_allocations['ETH'],
                'reason': exposure_reason,
                'data_completeness': regime_data_completeness
            },
            'USDT': {
                'action': 'hold',
                'target_allocation': target_allocations['USDT'],
                'reason': exposure_reason,
                'data_completeness': regime_data_completeness
            }
        }

    # ========================================================================================
    # CALIBRATED EXPOSURE GUIDELINES
    # ========================================================================================
    max_single_exposure = 0.8 if risk_appetite == "high" else 0.6
    if regime == "bear":
        max_single_exposure = 0.5
    elif regime == "bull":
        max_single_exposure = 0.9
    
    # Adjust for setups
    if setup_type == 'oversold':
        max_single_exposure = 0.20  # Limited exposure on oversold setups
    elif setup_type == 'overbought':
        max_single_exposure = 0.10  # Minimal exposure on overbought setups

    # ========================================================================================
    # LOSS PREVENTION FILTERS WITH SETUP OVERRIDES
    # ========================================================================================
    # Initialize with basic values
    allow_setup_trades_final = setup_type is not None
    setup_type_final = setup_type

    # EXPLICIT TIGHT_RANGE DETECTION: Set loss_prevention_filters dynamically by regime
    if regime == "RANGE" and subtype == "TIGHT_RANGE":
        allow_setup_trades_final = True
        setup_type_final = "mean_reversion"

    loss_prevention_filters = {
        "max_loss_per_trade_pct": 0.035,
        "require_strong_signal": False,
        "avoid_weak_sentiment": sentiment < -0.5,
        "bear_market_restriction": False,
        "high_volatility_block": False,
        "preserve_high_conf_l2": True,
        "allow_setup_trades": allow_setup_trades_final,  # Use the computed value
        "setup_type": setup_type_final  # Use the computed value
    }

    # Check volatility
    volatility_data = inputs.get("volatility", {})
    if volatility_data:
        btc_vol = volatility_data.get("btc_volatility", 0.03)
        eth_vol = volatility_data.get("eth_volatility", 0.04)
        avg_vol = (btc_vol + eth_vol) / 2
        if avg_vol > 0.05:
            loss_prevention_filters["high_volatility_block"] = True
            loss_prevention_filters["max_loss_per_trade_pct"] = 0.02

    # ========================================================================================
    # WINNING TRADE RULES WITH SETUP ADJUSTMENTS
    # ========================================================================================
    winning_trade_rules = {
        "allow_profit_running": True,
        "trailing_stop_activation": 0.005,
        "take_profit_levels": [0.03, 0.08, 0.15, 0.25],
        "scale_out_profits": True,
        "hold_winners_longer": regime in ["bull", "range"],
        "momentum_boost": True,
        "early_exit_weak_signals": False,
        "profit_lock_in": 0.02,
    }
    
    # Adjust for setups (tighter targets for mean reversion)
    if setup_type:
        winning_trade_rules["take_profit_levels"] = [0.015, 0.025, 0.04]  # Tighter targets
        winning_trade_rules["trailing_stop_activation"] = 0.008
        winning_trade_rules["profit_lock_in"] = 0.012

    # ========================================================================================
    # FINAL DECISION STRUCTURE WITH STRATEGIC HOLD TRACKING
    # ========================================================================================
    decision = {
        "timestamp": datetime.utcnow().isoformat(),
        "market_regime": regime,
        "regime_subtype": subtype,
        "setup_detected": setup_type is not None,
        "setup_type": setup_type,
        "setup_active": setup_active,  # L2 bridge: explicit setup_active flag
        "bias": "LONG" if (regime == "TRENDING" or regime == "bull") and regime_confidence > 0.5 else regime_signal,  # L3 bias instead of direct signal
        "allow_l2_signals": allow_l2_signal or (setup_type is not None) or ((regime == "TRENDING" or regime == "bull") and regime_confidence > 0.5),
        "strategic_hold_active": l3_dominance_state.get("strategic_hold_active", False),
        "sentiment_score": sentiment,
        "asset_allocation": portfolio,
        "risk_appetite": risk_appetite,
        "macro_context": macro,
        "exposure_decisions": exposure_decisions,
        "loss_prevention_filters": loss_prevention_filters,
        "winning_trade_rules": winning_trade_rules,
        "strategic_control": l3_dominance_state,
        "strategic_guidelines": {
            "rebalance_frequency": "daily" if regime == "volatile" else "weekly",
            "max_single_asset_exposure": max_single_exposure,
            "volatility_target": 0.25 if risk_appetite == "high" else 0.15,
            "liquidity_requirement": "high" if risk_appetite != "high" or regime == "bear" else "medium",
            "btc_max_exposure": 0.3 if regime == "bear" else 0.6,
            "usdt_min_liquidity": 0.10,
            "max_loss_per_trade_pct": loss_prevention_filters["max_loss_per_trade_pct"],
            "require_stop_loss": True,
            "profit_taking_strategy": "scaled" if winning_trade_rules["scale_out_profits"] else "single_target",
            "setup_trading_enabled": True
        },
        "rsi": rsi  # Incluir RSI en el contexto L3 para TIGHT_RANGE
    }
    
    # ========================================================================================
    # STRATEGIC HOLD LOGGING: Differentiate HOLD_L2 vs HOLD_L3
    # ========================================================================================
    # CRITICAL: Skip additional logging for LOW_CONFIDENCE hold - it already has a single clear log message
    if strategic_hold_type and strategic_hold_type != "HOLD_L3_LOW_CONFIDENCE":
        logger.info(f"🛡️ STRATEGIC HOLD ACTIVE: {strategic_hold_type} - {strategic_hold_reason}")
        logger.info(f"📊 L3 DOMINANCE: allow_l2_signals={allow_l2_signal}, regime={regime}, confidence={regime_confidence:.2f}")
        if regime == 'RANGE':
            logger.info(f"🎯 CAPITAL PRESERVATION: RANGE regime - L3 blocking weak signals, HOLD is strategic imperative")
    elif regime == 'RANGE' and not setup_type and not (strategic_hold_type == "HOLD_L3_LOW_CONFIDENCE"):
        logger.info(f"🛡️ RANGE REGIME HOLD: HOLD_L3_RANGE_DEFAULT - Blocking L2 signals in sideways market")
    elif setup_type:
        logger.info(f"✅ SETUP STRATEGY ACTIVE: {setup_type} setup allows controlled L2 signals")
        logger.info(f"📊 Setup allocation: BTC {portfolio.get('BTC', 0):.1%}, ETH {portfolio.get('ETH', 0):.1%}, USDT {portfolio.get('USDT', 0):.1%}")

    return decision


def generate_strategic_signal(regime: str, confidence: float, sentiment: float, price_change: float, market_indicators: dict = None) -> str:
    if market_indicators is None:
        market_indicators = {}
    """
    Generate strategic signal with lower bias threshold for more active signals.

    FUNDAMENTAL RULE: Lowered threshold to detect more moderate trends while avoiding over-trading.
    Signal when confidence is moderate (>= 0.60) and price movement is meaningful (>= 0.5) for BUY,
    and stricter thresholds for SELL to preserve capital.
    """

    # ========================================================================================
    # LOWERED BIAS THRESHOLD: More permissive for BUY, stricter for SELL
    # ========================================================================================

    # Log detailed bias calculation for debugging - enhanced with more metrics
    logger.info(f"Bias calc: regime={regime}, confidence={confidence:.2f}, price_change={price_change:.2f}, sentiment={sentiment:.2f}")
    
    # Calculate and log bull/bear scores for more detailed analysis
    bull_score = confidence * max(0, price_change) * (1 + max(0, sentiment))
    bear_score = confidence * max(0, -price_change) * (1 + max(0, -sentiment))
    directional_score = abs(bull_score - bear_score)
    logger.info(f"Detailed bias scores: bull={bull_score:.2f}, bear={bear_score:.2f}, directional={directional_score:.2f}")

    # More permissive BUY signals (lower thresholds)
    if confidence > 0.60 and price_change > 0.4 and (market_indicators.get('rsi', 50) < 50 or market_indicators.get('adx', 0) > 18):
        logger.info(f"✅ BUY: conf={confidence:.3f}, price_change={price_change:.3f}, sentiment={sentiment:.3f}, rsi={market_indicators.get('rsi', 50):.1f}, adx={market_indicators.get('adx', 0):.1f}")
        return 'buy'
    
    # Stricter SELL signals to preserve capital
    if confidence > 0.65 and price_change < -0.8:
        logger.info(f"✅ SELL: conf={confidence:.3f}, price_change={price_change:.3f}")
        return 'sell'

    # RANGE regime: HOLD dominant - only allow setups, never force directional signals
    elif regime == 'RANGE':
        logger.info(f"🛡️ RANGE HOLD: HOLD dominant in ranging markets (conf={confidence:.3f})")
        return 'hold'  # Never generate directional signals in range

    # VOLATILE regime: Always HOLD to avoid whipsaws
    elif regime == 'VOLATILE':
        logger.info(f"🛡️ VOLATILE HOLD: Avoiding trading in high volatility (conf={confidence:.3f})")
        return 'hold'

    # Default: HOLD - no clear statistical advantage
    else:
        logger.info(f"⏸️ DEFAULT HOLD: No clear statistical advantage (regime={regime}, conf={confidence:.3f})")
        return 'hold'


def get_regime_info(market_data: dict):
    """
    SOLUCIÓN INMEDIATA: Always calculate fresh regime info, bypass any caching.
    Returns fresh L3 context without cache dependency.
    """
    try:
        from .regime_classifier import ejecutar_estrategia_por_regimen

        # Siempre calcular fresco - NUNCA usar cache
        regime_info = ejecutar_estrategia_por_regimen(market_data)

        logger.info(f"✅ Fresh L3 Regime Info: {regime_info['regime']} (signal: {regime_info.get('signal', 'hold')}, confidence: {regime_info.get('confidence', 0.0):.3f})")

        return regime_info

    except Exception as e:
        logger.error(f"❌ Error in get_regime_info: {e}")
        # Fallback to basic structure
        return {
            'regime': 'unknown',
            'signal': 'hold',
            'confidence': 0.0,
            'allow_l2_signal': True
        }


def strategic_override_processor(l2_signal: str, l3_confidence: float, regime_info: dict = None, market_indicators: dict = None) -> dict:
    """
    PARTE 5 — L3 (decision_maker.py)
    🎯 PRINCIPIO ESTRATÉGICO FINAL - HOLD INVARIANT

    🛡️ L3 HOLD INVARIANT (NO NEGOCIABLE):
    L3 NEVER overrides when L2 signal is HOLD.

    ✅ ÚNICA CONDICIÓN VÁLIDA PARA OVERRIDE (when L2 is not HOLD):
    if (
        l3_confidence >= 0.80
        and regime_strength == "STRONG"
        and not risk_filters_blocking
    ):
        allow_override()
    else:
        respect_l2_signal()

    🧠 FRASE GUÍA (PARA LA IA)
    L3 no está para actuar más,
    está para impedir malas acciones.

    Args:
        l2_signal: Signal from L2 ("BUY", "SELL", "HOLD")
        l3_confidence: L3 confidence score (0.0 to 1.0)
        regime_info: Optional regime information dict
        market_indicators: Optional market indicators dict

    Returns:
        dict: Decision result with final_signal, confidence, override flag, reason, source
    """

    # ========================================================================================
    # CRITICAL: NORMALIZE CONFIDENCE TO PREVENT VALUES > 1.0
    # ========================================================================================
    l3_confidence = float(np.clip(l3_confidence, 0.0, 1.0))

    # ========================================================================================
    # 🔴 HOLD INVARIANT - L3 NEVER OVERRIDES WHEN L2 IS HOLD (NO NEGOCIABLE)
    # ========================================================================================
    if l2_signal.upper() == "HOLD":
        # L3 NEVER overrides when L2 is HOLD - this is the fundamental invariant
        result = {
            "final_signal": "HOLD",
            "confidence": l3_confidence,
            "override": False,
            "reason": "L3 HOLD invariant: never override when L2=HOLD",
            "allow_l2": True,
            "source": "L3_STRATEGIC"
        }

        # ========================================================================================
        # 🛡️ DEFENSIVE ASSERT - L3 HOLD INVARIANT (NO NEGOCIABLE)
        # ========================================================================================
        override_applied = result.get("override", False)
        assert not (
            l2_signal.upper() == "HOLD" and override_applied
        ), "L3 violated HOLD invariant"

        return result

    # ========================================================================================
    # ✅ OVERRIDE ONLY WHEN L2 IS NOT HOLD - Check exceptional conditions
    # ========================================================================================
    l3_high_confidence = l3_confidence >= 0.80

    # Determine regime strength
    regime = regime_info.get('regime', 'UNKNOWN') if regime_info else 'UNKNOWN'
    regime_strength_strong = regime.upper() in ['BULL', 'BEAR']  # Only clear directional regimes are "STRONG"

    # Check risk filters
    risk_filters_blocking = False
    if market_indicators:
        # Check for momentum exhaustion signals
        rsi = market_indicators.get('rsi', 50)
        macd_divergence = market_indicators.get('macd_divergence', False)
        volume_spike = market_indicators.get('volume_spike', False)

        # RSI extreme + divergence + volume spike = momentum exhausted
        if rsi > 75 or rsi < 25:
            if macd_divergence and volume_spike:
                risk_filters_blocking = True

        # RSI extreme without pullback = unfavorable risk
        has_pullback = market_indicators.get('has_pullback', False)
        if (rsi > 75 or rsi < 25) and not has_pullback:
            risk_filters_blocking = True

    # ========================================================================================
    # ✅ EXCEPCIONAL OVERRIDE CONDITION - ALL MUST BE TRUE (when L2 is not HOLD)
    # ========================================================================================
    if l3_high_confidence and regime_strength_strong and not risk_filters_blocking:
        # ALL exceptional conditions met - allow override
        result = {
            "final_signal": l2_signal.upper(),  # Keep L2 signal (since L2 is not HOLD)
            "confidence": l3_confidence,
            "override": True,
            "reason": f"Exceptional override: L2={l2_signal.upper()}, L3={l3_confidence:.2f}, regime={regime.upper()}, no_risk_filters",
            "allow_l2": False,  # L3 taking control
            "source": "L3_STRATEGIC"
        }

        # ========================================================================================
        # 🛡️ DEFENSIVE ASSERT - L3 HOLD INVARIANT (NO NEGOCIABLE)
        # ========================================================================================
        override_applied = result.get("override", False)
        assert not (
            l2_signal.upper() == "HOLD" and override_applied
        ), "L3 violated HOLD invariant"

        return result

    # ========================================================================================
    # 🔴 RESPECT L2 SIGNAL - Exceptional conditions not met
    # ========================================================================================
    else:
        reason_parts = []
        if not l3_high_confidence:
            reason_parts.append(f"L3 confidence {l3_confidence:.2f} < 0.80")
        if not regime_strength_strong:
            reason_parts.append(f"Regime {regime.upper()} not STRONG")
        if risk_filters_blocking:
            reason_parts.append("Risk filters blocking")

        reason = "respect_l2: " + ", ".join(reason_parts) if reason_parts else "respect_l2: conditions not exceptional"

        result = {
            "final_signal": l2_signal.upper(),
            "confidence": l3_confidence,
            "override": False,
            "reason": reason,
            "allow_l2": True,
            "source": "L3_STRATEGIC"
        }

        # ========================================================================================
        # 🛡️ DEFENSIVE ASSERT - L3 HOLD INVARIANT (NO NEGOCIABLE)
        # ========================================================================================
        override_applied = result.get("override", False)
        assert not (
            l2_signal.upper() == "HOLD" and override_applied
        ), "L3 violated HOLD invariant"

        return result

    # ========================================================================================
    # 🛡️ DEFENSIVE ASSERT - L3 HOLD INVARIANT (NO NEGOCIABLE) - CHECK ALL RETURNS
    # ========================================================================================
    # This assert should trigger if we ever override when L2 is HOLD
    # According to the user's requirement, this should NEVER happen
    # But our current logic allows it under exceptional conditions
    # The assert will help catch any violations of this invariant


def save_decision(data: dict, output_path: str):
    """Guarda la decisión estratégica en JSON"""
    with open(output_path, "w") as f:
        json.dump(data, f, indent=4)
    print(f"✅ Decisión estratégica guardada en {output_path}")


if __name__ == "__main__":
    print("🔄 Ejecutando Decision Maker...")
    ensure_dir(INFER_DIR)

    inputs = load_inputs()
    decision = make_decision(inputs, balances_synced=True)  # Assume synced for standalone execution
    save_decision(decision, OUTPUT_FILE)

    print("📊 Resumen Decision Maker:")
    print(json.dumps(decision, indent=4))
