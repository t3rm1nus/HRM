# l1_operational/config.py
"""
Configuración centralizada de L1_operational.
Contiene todos los límites de riesgo y parámetros de ejecución.
"""
import os
from typing import Dict, Optional, List, Any

# Modo de operación
OPERATION_MODE = "LIVE"  # "paper", "live", "development", "testing"

# Límites de riesgo por operación - OPTIMIZADOS PARA 3K USDT
RISK_LIMITS = {
    "MAX_ORDER_SIZE_BTC": 0.05,      # ~$5,420 por orden (más agresivo)
    "MAX_ORDER_SIZE_USDT": 1500,     # Máximo 50% del capital por orden
    "MIN_ORDER_SIZE_USDT": 2,        # Mínimo unificado a 2.0 USDT (Prompt 3A FIX)
    "MAX_ORDER_SIZE_ETH": 0.5,       # ~$2,185 por orden (más agresivo)
    "MAX_ORDER_SIZE_ADA": 100,       # Sin cambios
}
# Límites de riesgo por portafolio - OPTIMIZADOS PARA ROTACIÓN
PORTFOLIO_LIMITS = {
    "MAX_PORTFOLIO_EXPOSURE_BTC": 0.40,  # máximo 40% del portafolio en BTC
    "MAX_PORTFOLIO_EXPOSURE_ETH": 0.40,  # máximo 40% del portafolio en ETH
    "MAX_POSITION_SIZE_USDT": 1200,      # máximo $1200 por posición individual (40% de $3000)
    "MIN_USDT_RESERVE": 0.20,            # mínimo 20% siempre en USDT libre
    "REBALANCE_THRESHOLD": 0.15,         # rebalancear si USDT < 15% del total
    "REBALANCE_TRIGGER_THRESHOLD": 5,    # trigger rebalance si >= N stop-losses
    "REBALANCE_INTERVAL": 60,            # intervalo mínimo entre rebalances (segundos)
    "REBALANCE_MIN_AMOUNT": 500,         # monto mínimo para rebalance ($)
    "ROTATION_AMOUNT": 0.25,             # vender 25% cuando se active rotación
    "MAX_DAILY_DRAWDOWN": 0.08,          # aumentado a 8% de drawdown diario
    "MIN_ACCOUNT_BALANCE_USDT": 500,     # mínimo $500 USDT libre para operaciones
    "MAX_LEVERAGE": 1.0,                 # sin apalancamiento
    # PATH3 Auto-Rebalance Safety Features
    "ENABLE_AUTO_REBALANCE": True,       # circuit breaker para deshabilitar auto-rebalance
    "REBALANCE_CHECKSUM_VERIFICATION": True,  # verificar checksums para auditoría forense
    "REBALANCE_DRY_RUN_ENABLED": False,  # habilitar modo simulación para testing
    "REBALANCE_FEES_BUFFER": 1.01,       # buffer 1.01x para slippage/fees en sells
    "REBALANCE_COOLDOWN_EXTENDED": 300,  # cooldown extendido 5min para recuperarse
    "REBALANCE_MIN_ORDER_CHECK": True,   # verificar balance USDT para buys
    "REBALANCE_FORCE_INTERVAL": 100,     # force rebalancing every 100 cycles
}

# Configuración de ejecución
EXECUTION_CONFIG = {
    "DEFAULT_ORDER_TYPE": "market",
    "MAX_SLIPPAGE_BPS": 50,            # máximo 0.5% de slippage
    "ORDER_TIMEOUT_SECONDS": 30,       # timeout para órdenes
    "RETRY_ATTEMPTS": 3,               # intentos de reintento
    "PAPER_MODE": True,               # Paper trading mode by default
}

# Configuración de alertas
ALERT_CONFIG = {
    "ENABLE_RISK_ALERTS": True,
    "ENABLE_EXECUTION_ALERTS": True,
    "ENABLE_PERFORMANCE_ALERTS": True,
}

# Configuración de logging
LOGGING_CONFIG = {
    "LEVEL": "INFO",
    "FORMAT": "{time:YYYY-MM-DD HH:mm:ss} | {level} | {name}:{function}:{line} | {message}",
    "ENABLE_FILE_LOGGING": True,
    "LOG_FILE": "l1_operational.log",
}

# Umbrales IA
TREND_THRESHOLD = 0.1

# Rutas de modelos IA
AI_MODELS = {
    "MODELO1_PATH": "models/L1/modelo1_lr.pkl",
    "MODELO2_PATH": "models/L1/modelo2_rf.pkl", 
    "MODELO3_PATH": "models/L1/modelo3_lgbm.pkl",
    "AI_CONFIDENCE_THRESHOLD": 0.4,
    "ENSEMBLE_THRESHOLD": TREND_THRESHOLD,  # Usar tu TREND_THRESHOLD existente
}

# ============================================================================
# SOLUCIÓN AL ERROR DE IMPORTACIÓN - MEJORADA
# ============================================================================

class ConfigObject:
    """
    Objeto de configuración que encapsula todas las constantes.
    Soporta acceso tanto como clase como instancia.
    """
    
    # Atributos de clase (para acceso directo tipo ConfigObject.RISK_LIMITS)
    OPERATION_MODE = 'PAPER'
    RISK_LIMITS = RISK_LIMITS
    PORTFOLIO_LIMITS = PORTFOLIO_LIMITS
    EXECUTION_CONFIG = EXECUTION_CONFIG
    ALERT_CONFIG = ALERT_CONFIG
    LOGGING_CONFIG = LOGGING_CONFIG
    TREND_THRESHOLD = TREND_THRESHOLD
    AI_MODELS = AI_MODELS
    
    def __init__(self):
        # Atributos de instancia (para acceso tipo config.RISK_LIMITS)
        self.OPERATION_MODE = OPERATION_MODE
        self.RISK_LIMITS = RISK_LIMITS
        self.PORTFOLIO_LIMITS = PORTFOLIO_LIMITS
        self.EXECUTION_CONFIG = EXECUTION_CONFIG
        self.ALERT_CONFIG = ALERT_CONFIG
        self.LOGGING_CONFIG = LOGGING_CONFIG
        self.TREND_THRESHOLD = TREND_THRESHOLD
        self.AI_MODELS = AI_MODELS
        
        # Configuración de Binance para compatibilidad
        self.BINANCE_API_KEY = os.getenv('BINANCE_API_KEY', '')
        self.BINANCE_API_SECRET = os.getenv('BINANCE_API_SECRET', '')
        self.BINANCE_MODE = os.getenv('BINANCE_MODE', OPERATION_MODE.upper())
        self.USE_TESTNET = os.getenv('USE_TESTNET', 'true').lower() == 'true'
        
        # También como atributos de clase para compatibilidad total
        ConfigObject.BINANCE_API_KEY = self.BINANCE_API_KEY
        ConfigObject.BINANCE_API_SECRET = self.BINANCE_API_SECRET
        ConfigObject.BINANCE_MODE = self.BINANCE_MODE
        ConfigObject.USE_TESTNET = self.USE_TESTNET
    
    def get_risk_limit(self, asset, limit_type=None):
        """Obtener límite de riesgo específico"""
        key = f"MAX_ORDER_SIZE_{asset.upper()}"
        return self.RISK_LIMITS.get(key, 0)
    
    def get_portfolio_limit(self, asset):
        """Obtener límite de portafolio específico"""
        key = f"MAX_PORTFOLIO_EXPOSURE_{asset.upper()}"
        return self.PORTFOLIO_LIMITS.get(key, 0)
    
    def is_paper_mode(self):
        """Verificar si estamos en modo paper"""
        return self.OPERATION_MODE.upper() == "PAPER" or self.EXECUTION_CONFIG["PAPER_MODE"]

    def get(self, key, default=None):
        """Dictionary-like get method for compatibility"""
        return getattr(self, key, default)

    @classmethod
    def get_class_risk_limit(cls, asset, limit_type=None):
        """Método de clase para obtener límites"""
        key = f"MAX_ORDER_SIZE_{asset.upper()}"
        return cls.RISK_LIMITS.get(key, 0)
    
    @classmethod 
    def get_class_portfolio_limit(cls, asset):
        """Método de clase para obtener límites de portafolio"""
        key = f"MAX_PORTFOLIO_EXPOSURE_{asset.upper()}"
        return cls.PORTFOLIO_LIMITS.get(key, 0)

# Crear la instancia que será importada
config = ConfigObject()

# IMPORTANTE: También exportar la clase para acceso directo
Config = ConfigObject

# Mantener compatibilidad: exportar todo lo que ya existía
__all__ = [
    'config',        # Instancia (config.RISK_LIMITS)
    'Config',        # Clase (Config.RISK_LIMITS)
    'ConfigObject',  # Alias para la clase
    'OPERATION_MODE',
    'RISK_LIMITS', 
    'PORTFOLIO_LIMITS',
    'EXECUTION_CONFIG',
    'ALERT_CONFIG',
    'LOGGING_CONFIG',
    'TREND_THRESHOLD',
    'AI_MODELS'
]
